const button = document.querySelectorAll(".major");

button.forEach((each) => {
  each.addEventListener("click", (click) => {
    const check = click.currentTarget;
    check.classList.toggle("active");
    if (check.classList.contains("active")) {
      check.nextElementSibling.style.display = "inherit";
    } else {
      check.nextElementSibling.style.display = "none";
    }
  });
});
