const link = document.querySelectorAll(".link");
const course = document.querySelector(".course");
const contact = document.querySelector(".contact");

link[1].addEventListener("mouseover", () => {
  course.style.display = "inherit";
  course.addEventListener("mouseover", () => {
    course.style.display = "inherit";
  });
  course.addEventListener("mouseleave", () => {
    course.style.display = "none";
  });
});
link[1].addEventListener("mouseleave", () => {
  course.style.display = "none";
});
link[2].addEventListener("mouseover", () => {
  contact.style.display = "inherit";
  contact.addEventListener("mouseover", () => {
    contact.style.display = "inherit";
  });
  contact.addEventListener("mouseleave", () => {
    contact.style.display = "none";
  });
});
link[2].addEventListener("mouseleave", () => {
  contact.style.display = "none";
});
