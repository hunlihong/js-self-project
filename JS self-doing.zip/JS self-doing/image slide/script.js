const previous = document.querySelector(".icon-container > i:nth-child(1)");
const next = document.querySelector(".icon-container > i:nth-child(2)");
const images = document.querySelectorAll(".img > img");
const container = document.querySelector(".container");
let counter = 0;

function autoSliding() {
  interval = setInterval(() => {
    nextImg();
  }, 1500);
}
autoSliding();

next.addEventListener("mouseover", () => {
  clearInterval(interval);
});

previous.addEventListener("mouseover", () => {
  clearInterval(interval);
});

next.addEventListener("mouseleave", () => {
  autoSliding();
});

previous.addEventListener("mouseleave", () => {
  autoSliding();
});

next.addEventListener("click", () => {
  nextImg();
});

previous.addEventListener("click", () => {
  prevImg();
});

const nextImg = () => {
  images[counter].style.animation = "nextOut 0.5s forwards";
  if (counter >= images.length - 1) {
    counter = 0;
  } else {
    counter++;
  }
  images[counter].style.animation = "nextIn 0.5s forwards";
};

const prevImg = () => {
  images[counter].style.animation = "prevOut 0.5s forwards";
  if (counter == 0) {
    counter = images.length - 1;
  } else {
    counter--;
  }
  images[counter].style.animation = "prevIn 0.5s forwards";
};
