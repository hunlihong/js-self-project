const nav = document.querySelector(".nav-container");
const list_bar = document.querySelector(".bar-container");

list_bar.addEventListener("click", () => {
  if (list_bar.classList.contains("active")) {
    list_bar.classList.remove("active");
    nav.style.display = "none";
  } else {
    list_bar.classList.add("active");
    nav.style.display = "inherit";
  }
});
