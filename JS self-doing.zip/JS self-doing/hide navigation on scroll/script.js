let preScroll = window.pageYOffset;
window.onscroll = function () {
  let lastScroll = window.pageYOffset;
  if (preScroll > lastScroll) {
    document.querySelector(".nav").style.top = "0";
  } else {
    document.querySelector(".nav").style.top = "-100%";
  }
  preScroll = lastScroll;
};
