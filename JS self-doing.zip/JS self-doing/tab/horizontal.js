const button = document.querySelectorAll(".btn");
const display = document.querySelector(".display");
const displayMenu = [
  {
    id: "se",
    major: "Software Egineering",
    panel: "Software Engineering focuses on coding to build software.",
  },
  {
    id: "cncs",
    major: "Computer Networking and Cyber Security",
    panel:
      "Computer Networking and Cyber Security focuses on networking and system security (protecting and attacking)",
  },
  {
    id: "cmd",
    major: "Computer Multimedia Design",
    panel:
      "Computer Multimedia Design focuses on graphic designing, logo creation, and video editting.",
  },
];
button.forEach((btn) => {
  btn.addEventListener("click", (click) => {
    const check = click.currentTarget;
    const btnID = click.currentTarget.dataset.id;
    if (check.classList.contains("active")) {
      return null;
    } else {
      for (let i = 0; i < button.length; i++) {
        button[i].classList.remove("active");
      }
      check.classList.add("active");
    }
    const filterMenu = displayMenu.filter(function (e) {
      return e.id == btnID;
    });
    showing(filterMenu);
    display.style.display = "inherit";
  });
});
function showing(showingMajor) {
  const showing = showingMajor
    .map(function (m) {
      return `<h3 class="major">${m.major}</h3>
        <p class="panel">${m.panel}</p>`;
    })
    .join("");
  display.innerHTML = showing;
}
