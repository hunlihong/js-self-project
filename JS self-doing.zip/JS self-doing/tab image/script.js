const images = document.querySelectorAll(".img-wrapper > img");
const specific = document.querySelector(".specific > img");

images.forEach((each) => {
  each.addEventListener("click", (click) => {
    const src = click.currentTarget.getAttribute("src");
    specific.setAttribute("src", src);
  });
});
